-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 21, 2021 at 03:25 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Mobiles', '2021-06-21 16:11:13', '2021-06-21 16:38:44'),
(2, 'Labtops', '2021-06-21 16:11:26', '2021-06-21 16:39:01'),
(3, 'Clothes', '2021-06-21 16:11:33', '2021-06-21 16:39:11'),
(4, 'Sport', '2021-06-21 16:11:43', '2021-06-21 16:39:20'),
(6, 'Accessories', '2021-06-21 16:16:56', '2021-06-21 16:39:30'),
(7, 'Bags', '2021-06-21 16:17:00', '2021-06-21 16:40:02'),
(8, 'TVs', '2021-06-21 16:17:09', '2021-06-21 16:40:50'),
(9, 'PCs', '2021-06-21 16:41:25', '2021-06-21 16:41:25'),
(10, 'Camera', '2021-06-21 16:41:32', '2021-06-21 16:41:32'),
(11, 'Electronics', '2021-06-21 16:41:45', '2021-06-21 16:41:45');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `mobile`, `address`, `photo`, `created_at`, `updated_at`) VALUES
(1, 'Customer 1', 'customer1@inventory.com', '0523131434', 'address details 1 address details 1 address details 1 address details 1', 'uploads/customers/77187206524720210625162460396744145.jpeg', '2021-06-25 04:52:47', '2021-06-25 04:52:47'),
(2, 'Customer 2', 'customer2@inventory.com', '0523131432', 'address details 2 address details 2 address details 2', 'uploads/customers/53361306540220210625162460404232451.jpeg', '2021-06-25 04:53:33', '2021-06-25 04:54:25');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salary` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `joining_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `name`, `email`, `mobile`, `address`, `salary`, `photo`, `nid`, `joining_date`, `created_at`, `updated_at`) VALUES
(1, 'Employee 1', 'employee1@inventory.com', '01065252524', 'Address Details Address Details Address Details Address Details Address Details Address Details Address Details Address Details', '4500', 'uploads/employees/83726719274120210610162335326195707.jpeg', '29407011602013', '2017-07-01', '2021-06-10 03:50:53', '2021-06-21 16:45:00'),
(4, 'Employee 3', 'employee3@inventory.com', '01065252523', 'Address Details Address Details Address Details Address Details Address Details Address Details Address Details Address Details', '5000', 'uploads/employees/19485919280420210610162335328420474.jpeg', '29409171602011', '2015-09-17', '2021-06-10 03:58:39', '2021-06-21 16:44:40'),
(5, 'Employee 4', 'employee4@inventory.com', '01065252544', 'Address Details 4 Address Details 4 Address Details 4 Address Details 4 Address Details 4 Address Details 4 Address Details 4 Address Details 4', '3700', 'uploads/employees/1189940250422021062116242438428679.jpeg', '29705021602010', '2018-05-02', '2021-06-10 14:49:47', '2021-06-21 00:50:42'),
(6, 'Employee 5', 'employee5@inventory.com', '01065252525', 'Address Details 5 Address Details 5 Address Details 5', '6000', 'uploads/employees/68513719550120210610162335490191329.jpeg', '29008011602016', '2016-08-01', '2021-06-10 15:57:04', '2021-06-10 17:55:01'),
(7, 'Employee 6', 'employee6@inventory.com', '01065252526', 'Address Details 6 Address Details 6 Address Details 6 Address Details 6', '2800', 'uploads/employees/8677817584120210610162334792176310.jpeg', '39407191602020', '2020-07-20', '2021-06-10 15:58:41', '2021-06-21 01:19:10');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `details` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expense_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `details`, `amount`, `expense_date`, `created_at`, `updated_at`) VALUES
(1, 'Expense 1 Details Expense 1 Details Expense 1 Details Expense 1 Details Expense 1 Details Expense 1 Details Expense 1 Details Expense 1 Details Expense 1 Details Expense 1 Details Expense 1 Details Expense 1 Details Expense 1 Details Expense 1 Details Expense 1 Details Expense 1 Details Expense 1 Details Expense 1 Details Expense 1 Details Expense 1 Details', '1600', '2021-06-23 00:00:00', '2021-06-23 03:01:25', '2021-06-23 03:18:34'),
(2, 'Expense 2 Details Expense 2 Details Expense 2 Details Expense 2 Details Expense 2 Details', '2000', '2021-06-23 00:00:00', '2021-06-23 03:03:53', '2021-06-23 03:09:57'),
(3, 'Expense 3 Details Expense 3 Details', '1800', '2021-06-23 00:00:00', '2021-06-23 03:19:28', '2021-06-23 03:19:28'),
(5, 'details 4 details 4 details 4 details 4 details 4 details 4 details 4 details 4 details 4 details 4 details 4 details 4 details 4 details 4', '2000', '2021-07-21 00:00:00', '2021-07-21 10:49:37', '2021-07-21 10:49:37');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_06_10_030619_create_employees_table', 2),
(5, '2021_06_21_011416_create_suppliers_table', 3),
(6, '2021_06_21_173906_create_categories_table', 4),
(7, '2021_06_22_021311_create_products_table', 5),
(9, '2021_06_23_040940_create_expenses_table', 6),
(10, '2021_06_24_015007_create_salaries_table', 7),
(11, '2021_06_25_061628_create_customers_table', 8),
(12, '2021_07_18_015759_create_pos_table', 9),
(13, '2021_07_19_065245_create_settings_table', 10),
(16, '2021_07_21_060809_create_orders_table', 11),
(17, '2021_07_21_060830_create_order_details_table', 11);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `sub_total` decimal(18,2) UNSIGNED DEFAULT 0.00,
  `vat` decimal(18,2) UNSIGNED DEFAULT 0.00,
  `vat_value` decimal(18,2) UNSIGNED DEFAULT 0.00,
  `total` decimal(18,2) UNSIGNED DEFAULT 0.00,
  `pay` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `due` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pay_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_month` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_year` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_id`, `customer_name`, `quantity`, `sub_total`, `vat`, `vat_value`, `total`, `pay`, `due`, `pay_by`, `order_date`, `order_month`, `order_year`, `created_at`, `updated_at`) VALUES
(1, 1, 'Customer 1', 8, '32849.92', '14.00', '4598.99', '37448.91', '35000', '2448.91', 'HandCash', '2021-07-20', 'July', '2021', '2021-07-20 06:02:03', '2021-07-20 06:02:03'),
(2, 2, 'Customer 2', 5, '134999.95', '14.00', '18899.99', '153899.94', '153899.94', '0', 'Cheque', '2021-07-20', 'July', '2021', '2021-07-20 06:02:56', '2021-07-20 06:02:56'),
(3, 2, 'Customer 2', 4, '3249.96', '14.00', '454.99', '3704.95', '3000', '704.95', 'HandCash', '2021-07-21', 'July', '2021', '2021-07-21 09:04:22', '2021-07-21 09:04:22'),
(4, 1, 'Customer 1', 3, '76999.97', '14.00', '10780.00', '87779.97', '85000', '2779.97', 'Cheque', '2021-07-21', 'July', '2021', '2021-07-21 11:19:28', '2021-07-21 11:19:28'),
(5, 1, 'Customer 1', 7, '6499.93', '14.00', '909.99', '7409.92', '7409.92', '0', 'Cheque', '2021-07-21', 'July', '2021', '2021-07-21 11:20:16', '2021-07-21 11:20:16'),
(6, 1, 'Customer 1', 1, '649.99', '14.00', '91.00', '740.99', '740.99', '0', 'GiftCard', '2021-07-21', 'July', '2021', '2021-07-21 11:20:39', '2021-07-21 11:20:39');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` decimal(18,2) UNSIGNED DEFAULT 0.00,
  `sub_total` decimal(18,2) UNSIGNED DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `product_id`, `quantity`, `price`, `sub_total`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 1, '26999.99', '26999.99', '2021-07-20 06:02:03', '2021-07-20 06:02:03'),
(2, 1, 3, 2, '1299.99', '2599.98', '2021-07-20 06:02:03', '2021-07-20 06:02:03'),
(3, 1, 4, 5, '649.99', '3249.95', '2021-07-20 06:02:03', '2021-07-20 06:02:03'),
(4, 2, 2, 5, '26999.99', '134999.95', '2021-07-20 06:02:56', '2021-07-20 06:02:56'),
(5, 3, 3, 1, '1299.99', '1299.99', '2021-07-21 09:04:22', '2021-07-21 09:04:22'),
(6, 3, 4, 3, '649.99', '1949.97', '2021-07-21 09:04:22', '2021-07-21 09:04:22'),
(7, 4, 1, 2, '24999.99', '49999.98', '2021-07-21 11:19:28', '2021-07-21 11:19:28'),
(8, 4, 2, 1, '26999.99', '26999.99', '2021-07-21 11:19:28', '2021-07-21 11:19:28'),
(9, 5, 4, 4, '649.99', '2599.96', '2021-07-21 11:20:16', '2021-07-21 11:20:16'),
(10, 5, 3, 3, '1299.99', '3899.97', '2021-07-21 11:20:16', '2021-07-21 11:20:16'),
(11, 6, 4, 1, '649.99', '649.99', '2021-07-21 11:20:39', '2021-07-21 11:20:39');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pos`
--

CREATE TABLE `pos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` decimal(18,2) UNSIGNED DEFAULT 0.00,
  `sub_total` decimal(18,2) UNSIGNED DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `root` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `buying_price` decimal(18,2) UNSIGNED DEFAULT 0.00,
  `selling_price` decimal(18,2) UNSIGNED DEFAULT 0.00,
  `buying_date` datetime DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `supplier_id`, `name`, `code`, `root`, `quantity`, `buying_price`, `selling_price`, `buying_date`, `image`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 'Iphone 12 Pro Max 256GB', '000001', 'A', 8, '23999.99', '24999.99', '2021-06-21 00:00:00', 'uploads/products/93217712100920210622162436380955598.jpeg', '2021-06-22 10:10:09', '2021-07-21 11:19:28'),
(2, 1, 3, 'Iphone 12 Pro Max 512GB', '000002', 'B', 7, '25999.99', '26999.99', '2021-06-21 00:00:00', 'uploads/products/28615313485120210622162436973180158.jpeg', '2021-06-22 10:13:17', '2021-07-21 11:19:28'),
(3, 10, 3, 'Product 3', '000003', 'C', 14, '1199.99', '1299.99', '2021-06-22 00:00:00', 'uploads/products/12147413490520210622162436974563422.jpeg', '2021-06-22 10:24:07', '2021-07-21 11:20:16'),
(4, 3, 1, 'Product 5', '000004', 'D', 22, '499.99', '649.99', '2021-06-22 00:00:00', 'uploads/products/90554412251020210622162436471061648.jpeg', '2021-06-22 10:25:10', '2021-07-21 11:20:39');

-- --------------------------------------------------------

--
-- Table structure for table `salaries`
--

CREATE TABLE `salaries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `amount` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salary_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salary_month` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salary_year` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `salaries`
--

INSERT INTO `salaries` (`id`, `employee_id`, `amount`, `salary_date`, `salary_month`, `salary_year`, `created_at`, `updated_at`) VALUES
(1, 7, '2800', '2021-06-24', 'July', '2020', '2021-06-24 01:55:23', '2021-06-24 01:55:23'),
(2, 7, '2800', '2021-06-24', 'August', '2020', '2021-06-24 01:56:09', '2021-06-24 01:56:09'),
(3, 6, '6000', '2021-06-24', 'May', '2021', '2021-06-24 01:56:25', '2021-06-24 01:56:25'),
(4, 6, '6000', '2021-06-24', 'June', '2021', '2021-06-24 01:56:40', '2021-06-24 01:56:40'),
(5, 5, '3700', '2021-06-24', 'May', '2021', '2021-06-24 01:56:48', '2021-06-24 01:56:48'),
(6, 5, '3700', '2021-06-24', 'June', '2021', '2021-06-24 01:56:56', '2021-06-24 01:56:56'),
(7, 4, '5000', '2021-06-24', 'May', '2021', '2021-06-24 01:58:42', '2021-06-24 01:58:42'),
(8, 4, '5000', '2021-06-24', 'June', '2020', '2021-06-24 01:58:50', '2021-06-24 07:07:16'),
(9, 4, '5000', '2021-06-24', 'August', '2020', '2021-06-24 02:05:23', '2021-06-24 02:05:23'),
(10, 1, '4500', '2021-06-24', 'May', '2021', '2021-06-24 02:05:39', '2021-06-24 02:05:39'),
(11, 1, '4500', '2021-06-24', 'June', '2021', '2021-06-24 02:05:47', '2021-06-24 02:05:47'),
(12, 1, '4500', '2021-06-24', 'April', '2021', '2021-06-24 02:09:42', '2021-06-24 02:09:42'),
(13, 7, '2800', '2021-06-24', 'June', '2021', '2021-06-24 02:13:49', '2021-06-24 02:13:49'),
(14, 7, '2800', '2021-06-24', 'May', '2021', '2021-06-24 02:14:00', '2021-06-24 02:14:00'),
(15, 7, '2800', '2021-06-24', 'April', '2021', '2021-06-24 02:16:15', '2021-06-24 02:16:15'),
(16, 7, '2800', '2021-06-24', 'March', '2021', '2021-06-24 02:16:34', '2021-06-24 02:16:34'),
(17, 7, '2800', '2021-06-24', 'February', '2021', '2021-06-24 02:16:57', '2021-06-24 02:16:57'),
(18, 1, '4500', '2021-06-24', 'March', '2021', '2021-06-24 02:20:29', '2021-06-24 02:20:29'),
(19, 1, '4500', '2021-06-24', 'February', '2021', '2021-06-24 02:22:12', '2021-06-24 02:22:12'),
(20, 1, '4500', '2021-06-24', 'January', '2020', '2021-06-24 06:12:03', '2021-06-24 06:12:03'),
(21, 1, '4500', '2021-06-24', 'February', '2020', '2021-06-24 06:12:14', '2021-06-24 06:12:14'),
(22, 1, '4500', '2021-06-24', 'March', '2020', '2021-06-24 06:12:23', '2021-06-24 06:12:23'),
(23, 1, '4500', '2021-06-24', 'April', '2020', '2021-06-24 06:12:30', '2021-06-24 06:12:30'),
(24, 1, '4500', '2021-06-24', 'May', '2020', '2021-06-24 06:12:39', '2021-06-24 06:12:39'),
(25, 1, '4500', '2021-06-24', 'June', '2020', '2021-06-24 06:12:48', '2021-06-24 06:12:48'),
(26, 1, '4500', '2021-06-24', 'July', '2020', '2021-06-24 06:12:55', '2021-06-24 06:12:55'),
(27, 1, '4500', '2021-06-24', 'August', '2020', '2021-06-24 06:13:02', '2021-06-24 06:13:02'),
(28, 1, '4500', '2021-06-24', 'September', '2020', '2021-06-24 06:13:10', '2021-06-24 06:13:10'),
(29, 1, '4500', '2021-06-24', 'October', '2020', '2021-06-24 06:13:17', '2021-06-24 06:13:17'),
(30, 1, '4500', '2021-06-24', 'November', '2020', '2021-06-24 06:13:25', '2021-06-24 06:13:25'),
(31, 1, '4500', '2021-06-24', 'December', '2020', '2021-06-24 06:13:30', '2021-06-24 06:13:30'),
(32, 1, '4500', '2021-06-24', 'January', '2021', '2021-06-24 06:13:37', '2021-06-24 06:13:37'),
(33, 4, '5000', '2021-06-24', 'June', '2021', '2021-06-24 07:07:42', '2021-06-24 07:07:42'),
(34, 7, '2800', '2021-07-15', 'July', '2021', '2021-07-14 22:36:59', '2021-07-14 22:36:59'),
(35, 6, '6000', '2021-07-15', 'July', '2021', '2021-07-14 22:37:11', '2021-07-14 22:37:11'),
(36, 5, '3700', '2021-07-15', 'July', '2021', '2021-07-14 22:37:22', '2021-07-14 22:37:22'),
(37, 4, '5000', '2021-07-15', 'July', '2021', '2021-07-14 22:37:30', '2021-07-14 22:37:30'),
(38, 1, '4500', '2021-07-15', 'July', '2021', '2021-07-14 22:37:38', '2021-07-14 22:37:38');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `key`, `value`, `created_at`, `updated_at`) VALUES
(1, 'vat', '14', '2021-07-19 05:33:08', '2021-07-19 05:33:08');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shop_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `name`, `email`, `mobile`, `address`, `photo`, `shop_name`, `created_at`, `updated_at`) VALUES
(1, 'Supplier 1', 'supplier1@inventory.com', '0581235461', 'Supplier 1 Address Details Supplier 1 Address Details Supplier 1 Address Details', 'uploads/suppliers/26314602592920210621162424436946234.jpeg', 'Supplier 1 Shop', '2021-06-21 00:51:52', '2021-06-21 00:59:30'),
(2, 'Supplier 2', 'supplier2@inventory.com', '0581235462', 'Supplier 2 Address Details Supplier 2 Address Details Supplier 2 Address Details', 'uploads/suppliers/54262803000220210621162424440263907.jpeg', 'Supplier 2 Shop', '2021-06-21 00:52:51', '2021-06-21 01:00:02'),
(3, 'Supplier 3', 'supplier3@inventory.com', '0581235463', 'Supplier 3 Address Details Supplier 3 Address Details Supplier 3 Address Details', 'uploads/suppliers/88674003003920210621162424443932307.jpeg', 'Supplier 3 Shop', '2021-06-21 00:55:13', '2021-06-21 01:15:05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Mohamed Ismail', 'admin@inventory.com', NULL, '$2y$10$ugLj/Bvl0rAmYC4rusL1K.l2NSKc5NrwohGK0LG.RIhIiwz15Yvjy', NULL, '2021-06-09 22:35:24', '2021-06-09 22:35:24'),
(2, 'Manager 1', 'manager1@inventory.com', NULL, '$2y$10$6dkrCV1Pdk4ZdfbRkHzOkuYFRerLzWtaZ4hMjotWkBdMdsNqnt98O', NULL, '2021-06-09 22:36:13', '2021-06-09 22:36:13'),
(4, 'Manager 2', 'manager2@inventory.com', NULL, '$2y$10$SHdrApJaZ4pXYjnkAWmWOeJCUl7XpRNI5OuZLNGKTO.ItRCnZO68q', NULL, '2021-06-09 22:48:37', '2021-06-09 22:48:37'),
(5, 'Manager 3', 'manager3@inventory.com', NULL, '$2y$10$4kJvTwVVboZt9qddt94xl.Wj4b6Y9eoRpd00ZuvywUv2JCoDyhPGe', NULL, '2021-06-09 22:49:25', '2021-06-09 22:49:25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_details_order_id_foreign` (`order_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `pos`
--
ALTER TABLE `pos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pos_product_id_foreign` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salaries`
--
ALTER TABLE `salaries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `settings_key_unique` (`key`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `pos`
--
ALTER TABLE `pos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `salaries`
--
ALTER TABLE `salaries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `order_details_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `pos`
--
ALTER TABLE `pos`
  ADD CONSTRAINT `pos_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
